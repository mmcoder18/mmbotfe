import React, { useEffect, useState } from "react";
import Card from "../../shared/components/UIElements/Card";
// import ErrorModel from "../../shared/components/UIElements/ErrorModal";
import LoadingSpinner from "../../shared/components/UIElements/LoadingSpinner";

const PaymentProvider = () => {
  // const { isLoading, error, sendRequest, clearError } = useHttpClient();
  const [loadedUsers, setLoadedUsers] = useState();
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    const sendRequested = async () => {
      try {
        setIsLoading(true);
        const request = require("request");

        const baseUrl = "https://api.binance.com";
        const endpoint = "/api/v3/trades";
        const method = "GET";

        const options = {
          method: method,
          url: baseUrl + endpoint
        };

        request.get(options, function(error, response, responseBody) {
          //console.log("response:", JSON.stringify(responseBody));
          setLoadedUsers(JSON.stringify(response));
        });
        setIsLoading(false);
      } catch (err) {
        setIsLoading(false);
        console.log(err);
      }
    };
    sendRequested();
  }, []);

  return (
    <React.Fragment>
      {isLoading && (
        <div className="center">
          <LoadingSpinner />
        </div>
      )}
      <Card>{!isLoading && loadedUsers && <div>{loadedUsers}</div>};</Card>
    </React.Fragment>
  );
};

export default PaymentProvider;
