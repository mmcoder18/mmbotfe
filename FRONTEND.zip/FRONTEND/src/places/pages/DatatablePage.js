import React from "react";
import DataTable, { createTheme } from "react-data-table-component";

createTheme("solarized", {
  text: {
    primary: "#268bd2",
    secondary: "#2aa198"
  },
  background: {
    default: "#002b36"
  },
  context: {
    background: "#cb4b16",
    text: "#FFFFFF"
  },
  divider: {
    default: "#073642"
  },
  action: {
    button: "rgba(0,0,0,.54)",
    hover: "rgba(0,0,0,.08)",
    disabled: "rgba(0,0,0,.12)"
  }
});

const data = [
  {
    id: 1,
    Asset: "Bitcoin (BTC)",
    Price: "7104.05",
    USDPrice: "$7111.51",
    Marketcap: "655.6m",
    Chg24h: "+4.75%",
    Chg7d: "+11.8%"
  },
  {
    id: 2,
    Asset: "ETH/USDT",
    Price: "156",
    USDPrice: "$160.51",
    Marketcap: "227.6m",
    Chg24h: "+8.15%",
    Chg7d: "+28.8%"
  },
  {
    id: 3,
    Asset: "XRP/USDT",
    Price: "0.1895",
    USDPrice: "$0.1865",
    Marketcap: "84.1m",
    Chg24h: "+5.12%",
    Chg7d: "+9.41%"
  },
];
const columns = [
  {
    name: "Asset",
    selector: "Asset",
    sortable: true
  },
  {
    name: "Price",
    selector: "Price",
    sortable: true
  },
  {
    name: "USD Price",
    selector: "USDPrice",
    sortable: true,
    right: true
  },
  {
    name: "Market cap",
    selector: "Marketcap",
    sortable: true
  },
  {
    name: "Chg24h",
    selector: "Chg24h",
    sortable: true,
    right: true
  },
  {
    name: "Chg7d",
    selector: "Chg7d",
    sortable: true,
    right: true
  }
];

class DatatablePage extends React.Component {
  render() {
    return <DataTable title="USDT" columns={columns} data={data} />;
  }
}

export default DatatablePage;
