import React, { useEffect, useState } from "react";
import Card from "../../shared/components/UIElements/Card";
// import ErrorModel from "../../shared/components/UIElements/ErrorModal";
import LoadingSpinner from "../../shared/components/UIElements/LoadingSpinner";

const SELLLAToken = () => {
  // const { isLoading, error, sendRequest, clearError } = useHttpClient();
  const [loadedUsers, setLoadedUsers] = useState();
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    const sendRequested = async () => {
      try {
        setIsLoading(true);
        const request = require("request");
        const crypto = require("crypto");

        const apiKey = "e5f2c5a9-c9e7-4a8d-80ed-4db94a0e73e9";
        const apiSecret = "YzI0YzMyYTEtMWYxOS00OWQyLTg3OWMtNWM1NmM2MzY4Nzcz";
        const method = "POST";
        const baseUrl = "https://api.latoken.com";
        const endpoint = "/v2/auth/order/place";

        const params = {
          baseCurrency: "34629b4b-753c-4537-865f-4b62ff1a31d6",
          quoteCurrency: "620f2019-33c0-423b-8a9d-cde4d7f8ef7f",
          side: "BUY",
          condition: "IMMEDIATE_OR_CANCEL",
          type: "MARKET",
          clientOrderId: "marketmaking1",
          price: 0.00007892,
          quantity: 10,
          timestamp: Date.now()
        };
        const body = JSON.stringify(params);
        const bodySignParams = Object.entries(params)
          .map(([key, val]) => key + "=" + val)
          .join("&");

        const signature = crypto
          .createHmac("sha256", apiSecret)
          .update(method + endpoint + bodySignParams)
          .digest("hex");

        const options = {
          method: method,
          url: baseUrl + endpoint,
          headers: {
            "Content-Type": "application/json",
            "X-LA-APIKEY": apiKey,
            "X-LA-SIGNATURE": signature
          },
          body: body
        };

        request.post(options, function(error, response, responseBody) {
          console.log('response body:', JSON.stringify(responseBody));
          console.log('response:', JSON.stringify(response));
          setLoadedUsers(JSON.stringify(response));
        });
        setIsLoading(false);
      } catch (err) {
        setIsLoading(false);
        console.log(err);
      }
    };
    sendRequested();
  }, []);

  return (
    <React.Fragment>
      {isLoading && (
        <div className="center">
          <LoadingSpinner />
        </div>
      )}
      <Card>{!isLoading && loadedUsers && <div>{loadedUsers}</div>};</Card>
    </React.Fragment>
  );
};

export default SELLLAToken;
